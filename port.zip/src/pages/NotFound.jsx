export const NotFound = () => {
  return <div> NotFound</div>;
};
